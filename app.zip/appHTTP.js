// komalpreet kaur (0004156)//
const http =require('http');

const jsonArray=JSON.stringify([
    {id: 1,course:"web Development"},
    {id:2,course:"programing"},
    {id:3,course:"Database"}
]);

 const server =http.createServer((req,res) =>{
 if (req.url== "/"){
    res.writeHead(200,{'content-type':'html'});
    res.write('<h1> Hello Focus college,<h1>');
    res.end();
} else if (req.url=='/courses') {
    res.writeHead(200,{'contenr-Type':'application/json'});
    res.write(jsonArray);
    res.end();
}
else {
    res.writeHead(404,{'content-Type':'html'});
    res.write('<h1>404-page Not Found');
    res.end();
 }
 });

 server.listen(3000);

 console.log('Listening to port 3000');



    
 

    

