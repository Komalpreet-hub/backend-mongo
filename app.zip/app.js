
function sayHello(name){
    console.log('My First Node Program - '+name);
}

sayHello('komalpreet');