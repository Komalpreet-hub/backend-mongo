// komalpreet kaur (0004156)//
console.log("filename:");
console.log(__filename);

console.log("DIRECTORY NAME:");
console.log(__dirname);