// komalpreet kaur (0004156)//
const os =require('os');

let totalMem =os.totalmem();
let freeMem =os.freemem();

totalMem = totalMem/1024/1024/1024;
freeMem = freeMem/1024/1024/1024;


console.log('Total Memory:'+totalMem.toFixed(0)+ " GB");
console.log('Free Memory:'+freeMem.toFixed(0) + " GB");
console.log("OS version:"+ os.version());
