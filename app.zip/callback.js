// komalpreet kaur (0004156)//
function tickDate(){
    const now =new Date();
    console.log("Actual Date and Time:"+now);
}

setInterval(tickDate,5000);